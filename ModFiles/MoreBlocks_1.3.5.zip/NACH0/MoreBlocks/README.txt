MoreBlocks for Colony Survival is made by NACH0CHEE5E

**run fix.bat if most fo teh items and blocks are broken**

For this mod to work you will need NewColonyAPI by JackPS9: https://github.com/Dorky106/NewColonyAPI/releases

textures were either made by me or were used with permission from: https://www.planetminecraft.com/texture_pack/cmr-exterme-realistic-256x-bump-mapping/

meshes are from: https://www.turbosquid.com/